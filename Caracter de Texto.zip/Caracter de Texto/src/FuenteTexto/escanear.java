/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FuenteTexto;

/**
 *
 * @author fabio
 */

import java.awt.Color;
import java.awt.Frame;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class escanear {
    
    /*se crean los arreglos que almacenaran las coordenadas de
    los pixeles que conforman el trazo de la letra en la imagen*/
    int ArregloX[]=new int[20000];
    int ArregloY[]=new int[20000];
    
    int z=0, h=0;
    
    //Imagen actual que se ha cargado
    private BufferedImage imageActual;
    
    //M�todo que devuelve una imagen abierta desde archivo
    //Retorna un objeto BufferedImagen
    public BufferedImage abrirImagen(){
        //Creamos la variable que ser� devuelta (la creamos como null)
        BufferedImage bmp=null;
        //Creamos un nuevo cuadro de di�logo para seleccionar imagen
        JFileChooser selector=new JFileChooser();
        //Le damos un t�tulo
        selector.setDialogTitle("Seleccione una imagen");
        //Filtramos los tipos de archivos
        FileNameExtensionFilter filtroImagen = new FileNameExtensionFilter("JPG & GIF & BMP", "jpg", "gif", "bmp");
        selector.setFileFilter(filtroImagen);
        //Abrimos el cuadro de di�log
        int flag=selector.showOpenDialog(null);
        //Comprobamos que pulse en aceptar
        if(flag==JFileChooser.APPROVE_OPTION){
            try {
                //Devuelve el fichero seleccionado
                File imagenSeleccionada=selector.getSelectedFile();
                //Asignamos a la variable bmp la imagen leida
                bmp = ImageIO.read(imagenSeleccionada);
            } catch (Exception e) {
                //no hacer ningun evento
            }
                 
        }
        //Asignamos la imagen cargada a la propiedad imageActual
        imageActual=bmp;
        //Retornamos el valor
        return bmp;
    }
    
    public BufferedImage escaneador(){
        
        //Variables que almacenar�n el valor del color que tiene el pixel
        int valR,valG,valB;
        //Variable que almacenar� el color del pixel
        Color colorAux;
             
        //Recorremos la imagen p�xel a p�xel
        for( int i = 0; i < imageActual.getWidth(); i++ ){
            for( int j = 0; j < imageActual.getHeight(); j++ ){
                //Almacenamos el color del p�xel
                colorAux=new Color(this.imageActual.getRGB(i, j));
                //Recogemos el valor del color del pixel(rojo,verde,azul)
                valR = colorAux.getRed();
                valG = colorAux.getGreen();
                valB = colorAux.getBlue();
                //Filtramos los pixeles que tengan un valor de color menor a 10
                //Es decir, solo los pixeles que sean colores cercanos o totalmente negros
                if(valR < 10 || valG < 10 || valB < 10){
                    ArregloX[z]=i;
                    ArregloY[z]=j;
                    z++;
                }

            }
        }
        //Retornamos la imagen
        return imageActual;  
    }
    
    /*Creamos un metodo para almacenar las coordenadas de 
    aquellos pixeles filtrados que se encuentre
    en el eje x de la imagen mediante un arreglo distinto para ser utilizado
    en clases externas*/
    public int [] AlmacenA(){
        int ArregloA[]=new int[20000];
        
        for( int i = 0; i < 20000; i++ ){
                ArregloA[i]=ArregloX[i];
            }
        return ArregloA;
    }
    
    /*Creamos un metodo para almacenar las coordenadas de 
    aquellos pixeles filtrados que se encuentre
    en el eje y de la imagen mediante un arreglo distinto para ser utilizado
    en clases externas*/
    public int [] AlmacenB(){
        int ArregloB[]=new int[20000];
        
        for( int i = 0; i < 20000; i++ ){  
                ArregloB[i]=ArregloY[i];
            }
        return ArregloB;
    }    
  
}