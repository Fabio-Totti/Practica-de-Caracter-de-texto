/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FuenteTexto;

/**
 *
 * @author fabio
 */


import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;
import java.awt.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 * Trazos.java <BR>
 * @author: Fabio
 */
public class Pantalla extends JFrame{
    //creamos los arreglos que recibiran las coordenadas de los pixeles que conforman el trazo
    int ArregloX[]=new int[20000];
    int ArregloY[]=new int[20000];

    //Instanciamos las variable de Glut
    static GL gl;
    static GLU glu;
    
    //Se crea el main
    public static void main (String args[]){
        Pantalla frame = new Pantalla();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
    
    
    //Se crea el metodo Constructor
    public Pantalla (){
        
        //Asignamos propiedades basicas a la ventana
        setTitle("Trazo de letra");
        setSize(400,400);
        setLocationRelativeTo(null);
        //Instanciamos la clase Graphic
        GraphicListener listener = new GraphicListener();
        //Creamos el canvas
        GLCanvas canvas = new GLCanvas(new GLCapabilities());
        canvas.addGLEventListener(listener);
        getContentPane().add(canvas);
    } 
    
    //se crea la clase GraphicListener
     public class GraphicListener implements GLEventListener{
        public void display(GLAutoDrawable arg0) {
           //Indicamos el tama�o del pixel
           gl.glPointSize(1.5f);
           //Asiganamos el color
           gl.glColor3f(0.5f, 5.5f, 0.5f);
           gl.glPushMatrix();
           //trasladamos el punto origen para centrar mejor el trazo con la ventana
           gl.glTranslated(-65, -40, 0);
           //Indicamos que vamos a iniciar a crear puntos
           gl.glBegin(GL.GL_POINTS);
           //Mediante los arreglos obtenemos las coordenadas en donde debemos dibujar el punto
           //para ello es utilizado un for
           for( int i = 0; i < 20000; i++ ){
                gl.glVertex2d(ArregloX[i], ArregloY[i]);
                System.out.println("x="+ArregloX[i]+"   y="+ArregloY[i]);  
            }
           //Deshabilitamos la creacion de lineas (de la maquina de estados )
           gl.glEnd();
           gl.glPopMatrix();
           gl.glFlush(); 
        }
        public void init(GLAutoDrawable arg0) {
            glu = new GLU();
            gl = arg0.getGL();
            gl.glClearColor(0, 0, 0, 0);
            //Establecer los parametros para la proyeccion
            gl.glMatrixMode(gl.GL_PROJECTION);
            glu.gluOrtho2D(0, 300, 300, 0);
            
        }

        public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {

        }

        public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {

        }

    }
  

}
